package com.athena.dintshang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DintshangApplication {

	public static void main(String[] args) {
		SpringApplication.run(DintshangApplication.class, args);
	}
}
